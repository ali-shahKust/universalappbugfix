package com.sherdle.universal.providers.woocommerce.model;

import android.view.View;

public class ViewItem {
    public View view;

    public ViewItem(View view){
        this.view = view;
    }
}
