package com.sherdle.universal.providers.photos.api;

public interface PhotoProvider {

    void requestPhotos(int page);

}
